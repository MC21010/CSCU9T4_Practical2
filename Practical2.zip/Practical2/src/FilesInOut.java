import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FilesInOut {
    @SuppressWarnings("resource")
	public static void main(String[] args) {
        String inputFileName;
        String outputFileName;

        if (args.length == 2) {
            inputFileName = args[0];
            outputFileName = args[1];
        } else {
            System.out.println("inputFileName outputFileName");
            return;
        }

        File inputFile = new File(inputFileName);
        Scanner inputScanner;
        try {
            inputScanner = new Scanner(inputFile);
        } catch (FileNotFoundException e) {
            System.out.println("Input file not found.");
            return;
        }

        File outputFile = new File(outputFileName);
        PrintWriter outputWriter;
        try {
            outputWriter = new PrintWriter(outputFile);
        } catch (FileNotFoundException e) {
            System.out.println("Output file not found.");
            return;
        }

        while (inputScanner.hasNextLine()) {
            String line = inputScanner.nextLine();
            String[] words = line.split(" ");
            for (String word : words) {
                outputWriter.println(word);
            }
        }

        inputScanner.close();
        outputWriter.close();
    }
}
